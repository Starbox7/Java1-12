import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

// "��â" 
public class NewWindow extends JFrame{
    JLabel label = new JLabel();
    JButton okButton = new JButton("OK");
    public NewWindow(String title) {
    	super(title);
    	setLayout(new FlowLayout());
    	Container c = getContentPane();
        label.setText(title);
        c.add(label);
        c.add(okButton);
        okButton.addMouseListener(new MouseAdapter() {
        		public void mousePressed(MouseEvent e) {
        			setVisible(false);
        		}
        });
        setSize(300,200);
        setVisible(true);
    }
}
